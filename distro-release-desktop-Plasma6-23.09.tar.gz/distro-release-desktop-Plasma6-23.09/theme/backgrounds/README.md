Add this
convert -fill white -pointsize 20 -gravity center -draw "text 300,410 'Rolling'" OpenMandriva-16x9.png test.png
