Plasma6 OpenMandriva config
